from strategies.classic_strategy import Disptcher


dp = Disptcher()
